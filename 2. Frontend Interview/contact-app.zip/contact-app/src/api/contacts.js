import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:3006/",
});

export const getAllContacts = async () => {
  const response = await api.get("/contacts");
  return response.data;
};

export const addContact = async (requestBody) => {
  const response = await api.post("/contacts", requestBody);
  return response;
};

export const updateContact = async (id, requestBody) => {
  const response = await api.put(`/contacts/${id}`, requestBody);
  return response;
};

export const deleteContact = async (id) => {
  await api.delete(`/contacts/${id}`);
};

export default api;
