import React, { useState, useEffect } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Switch,
  Route,
  data,
} from "react-router-dom";
import "./App.css";
import { v4 as uuid } from "uuid";
import Header from "./Header";
import AddContact from "./AddContact";
import ContactList from "./ContactList";
import ContactDetail from "./ContactDetail";
import {
  getAllContacts,
  addContact,
  deleteContact,
  updateContact,
} from "../api/contacts";
import EditContact from "./EditContact";
function App() {
  const LOCAL_STORAGE_KEY = "contacts";
  const [contacts, setContacts] = useState([]);

  // Get data from localstorage on first load
  // useEffect(() => {
  //   const retriveContact = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY));
  //   if (retriveContact) setContacts(retriveContact);
  // }, []);

  // Save data in localstorage when change in contact list
  // useEffect(() => {
  //   if (contacts.length > 0) {
  //     localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(contacts));
  //   }
  // }, [contacts]);

  // Retrieve data on first load from server.
  useEffect(() => {
    getAllContacts().then((data) => {
      setContacts(data);
    });
  }, []);

  // Add contacts
  const addContactHandler = (contact) => {
    const requestBody = {
      id: uuid(),
      ...contact,
    };
    addContact(requestBody).then((data) => {
      setContacts([...contacts, { id: uuid(), ...requestBody.data }]);
    });
  };

  // Update Contacts
  const updateContactHandler = (id, contact) => {
    console.log(contact);
    updateContact(id, contact);
    setContacts(
      contacts.map((cntct) => {
        if (cntct.id == id) {
          cntct.name = contact.name;
          cntct.email = contact.email;
        }
        return contact;
      })
    );
    console.log(contacts);
  };

  // Delete contacts
  const removeContactHandler = async (id) => {
    await deleteContact(id);
    const newContactList = contacts.filter((contact) => {
      return contact.id !== id;
    });
    setContacts(newContactList);
  };

  return (
    <div className="ui container">
      <Router>
        <Header />
        <Routes>
          <Route
            path="/add"
            element={<AddContact addContactHandler={addContactHandler} />}
          />
          <Route
            path="/"
            element={
              <ContactList
                contacts={contacts}
                getContactId={removeContactHandler}
              />
            }
          />
          <Route path="/contact/:id" element={<ContactDetail />} />
          <Route
            path="/contact/edit"
            element={
              <EditContact updateContactHandler={updateContactHandler} />
            }
          />
        </Routes>
        {/* <AddContact addContactHandler={addContactHandler} /> */}
        {/* <ContactList contacts={contacts} getContactId={removeContactHandler} /> */}
      </Router>
    </div>
  );
}

export default App;
