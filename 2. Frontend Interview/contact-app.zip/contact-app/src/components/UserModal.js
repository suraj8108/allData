import React, { useEffect, useState } from "react";
import user from "../images/user.jpg";
import { useNavigate } from "react-router-dom";

const UserModal = ({ showModal, userDetails, deleteContact, closeModal }) => {
  const [showModalView, setShowModalView] = useState(showModal);
  useEffect(() => {
    setShowModalView(showModal);
  }, [showModal]);
  // console.log(showModal);
  return (
    <div
      className="ui modal"
      style={{ display: showModalView === "true" ? "block" : "none" }}
    >
      <i className="close icon" onClick={(e) => closeModal()}></i>
      <div className="header">Delete User</div>
      <div className="image content">
        <div className="ui medium image">
          <img src={user} alt="user" />
        </div>
        <div className="description">
          <div className="ui header">Hi, {userDetails.name}</div>
          <p>Contact Email: {userDetails.email}</p>
          <p style={{ color: "red" }}>Do you want to delete this?</p>
        </div>
      </div>
      <div className="actions">
        <div className="ui black deny button">
          <a onClick={(e) => closeModal()} style={{ color: "white" }}>
            Nope{" "}
          </a>
        </div>
        <a
          onClick={() => {
            deleteContact(userDetails.id);
          }}
          style={{ color: "white" }}
        >
          <div className="ui negative right labeled icon button">
            {" "}
            Yes I want to delete <i className="checkmark icon"></i>
          </div>
        </a>
      </div>
    </div>
  );
};

export default UserModal;
