import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

const EditContact = (props) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { id, name, email } = location.state.userDetails;
  const [formData, setFormData] = useState({
    name: name,
    email: email,
  });

  const updateContact = (e) => {
    e.preventDefault();
    if (
      formData.name === "" ||
      formData.email === "" ||
      formData.email === "@gmail.com"
    ) {
      alert("All the fields are mandatory");
      return;
    }
    if (formData.name === name && formData.email === email) {
      alert("Please update some details");
      return;
    }

    props.updateContactHandler(id, formData);
    setFormData({ name: "", email: "@gmail.com" });
    navigate("/");
  };

  return (
    <div className="ui main">
      <h2>Add Contact</h2>
      <form className="ui form" onSubmit={updateContact}>
        <div className="field">
          <label>Name</label>
          <input
            type="text"
            name="name"
            placeholder="Name"
            value={formData.name}
            onChange={(e) => {
              console.log(e.target.value);
              setFormData({ ...formData, name: e.target.value });
            }}
          />
        </div>
        <div className="field">
          <label>Email</label>
          <input
            type="text"
            name="email"
            placeholder="email"
            value={formData.email}
            onChange={(e) =>
              setFormData({ ...formData, email: e.target.value })
            }
          />
        </div>
        <button className="ui button blue"> Update </button>
      </form>
    </div>
  );
};

export default EditContact;
