import React from "react";
import user from "../images/user.jpg";
import { Link, useLocation } from "react-router-dom";
const ContactDetail = (props) => {
  const location = useLocation();
  let { name, email } = location.state;
  return (
    <div className="main">
      <div className="ui card centered">
        <img src={user} />
        <div className="content">
          <div className="header">{name}</div>
          <div className="description">{email}</div>
        </div>
        <div
          className="center-div"
          style={{ display: "flex", justifyContent: "center" }}
        >
          <Link to="/">
            <button
              className="ui button blue center"
              style={{ marginBottom: "10px" }}
            >
              Back to Contact List
            </button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ContactDetail;
