import React, { useEffect, useState } from "react";
import user from "../images/user.jpg";
import { Link, useNavigate } from "react-router-dom";
import UserModal from "./UserModal";

const CardContact = (props) => {
  // const navigate = useNavigate();
  const [showModal, setShowModal] = useState("false");
  const [deleteModal, setDeleteModal] = useState();

  let userDetails = {
    id: props.id,
    name: props.name,
    email: props.email,
  };

  const deleteContact = () => {
    setShowModal("true");
  };

  const closeModal = () => {
    setShowModal("false");
  };

  return (
    <div>
      <hr />
      <div
        className="item"
        key={userDetails.id}
        style={{ display: "flex", justifyContent: "space-between" }}
      >
        <div style={{ display: "flex" }}>
          <img
            className="ui avatar image"
            src={user}
            alt="user"
            style={{ marginTop: "5px" }}
          />
          <div className="content">
            <Link to={`/contact/${userDetails.id}`} state={userDetails}>
              <div className="header">Name: {userDetails.name}</div>
              <div>Emailid: {userDetails.email}</div>
            </Link>
          </div>
        </div>
        <div>
          <Link to="/contact/edit" state={{ userDetails }}>
            <i class="edit icon"></i>
          </Link>
          <i
            className="trash alternate outline icon"
            onClick={() => {
              //
              deleteContact();
            }}
            style={{ color: "red", marginTop: "10px" }}
          />
        </div>
        <UserModal
          key={userDetails.id}
          showModal={showModal}
          userDetails={userDetails}
          deleteContact={props.getContactId}
          closeModal={closeModal}
        />
      </div>
    </div>
  );
};

export default CardContact;
