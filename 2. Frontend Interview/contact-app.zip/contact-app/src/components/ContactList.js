import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import CardContact from "./ContactCard";

const ContactList = (props) => {
  const [searchContact, setSearchContact] = useState(props.contacts);

  useEffect(() => {
    setSearchContact(sortData(props.contacts));
  }, [props.contacts]);

  const sortData = (contacts) => {
    contacts.sort((contact1, contact2) => {
      if (contact1.name.localeCompare(contact2.name) == 0) {
        return contact1.email.localeCompare(contact2.email);
      } else {
        return contact1.name.localeCompare(contact2.name);
      }
    });
    return contacts;
  };
  const filterData = (searchItem) => {
    if (searchItem == "") {
      setSearchContact(sortData(props.contacts));
      return;
    }
    const updatedData = props.contacts.filter((contact) => {
      return (
        contact.name.includes(searchItem) || contact.email.includes(searchItem)
      );
    });
    setSearchContact(updatedData);
    // console.log(updatedData);
  };
  const renderContactList = searchContact.map((contact) => {
    return (
      <CardContact
        key={contact.id}
        id={contact.id}
        name={contact.name}
        email={contact.email}
        getContactId={props.getContactId}
      />
    );
  });
  return (
    <div>
      <h2>Contact List </h2>
      <Link to="/add">
        <button className="ui button blue right">Add Contact</button>
      </Link>
      <div className="ui search">
        <div className="ui icon input">
          <input
            type="text"
            placeholder="Search contacts"
            className="prompt"
            onChange={(e) => filterData(e.target.value)}
          />
        </div>
      </div>
      {searchContact.length > 0 ? (
        <div className="ui celled list">{renderContactList}</div>
      ) : (
        <div> No contacts available </div>
      )}
    </div>
  );
};

export default ContactList;
