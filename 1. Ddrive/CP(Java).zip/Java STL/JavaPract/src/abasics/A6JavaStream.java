package abasics;

import java.util.*;
import java.util.stream.Collectors;

public class A6JavaStream {

	public static void main(String[] args) {
		List<Integer> elements = new ArrayList<>();
		Collections.addAll(elements, 53,24,24,64,7354,3,5,23,56,45);
		
		List<Integer> twice = elements.stream().map(element -> element*2).collect(Collectors.toList());
		
		List<Integer> mod = elements.stream().filter((element) -> element > 30).collect(Collectors.toList());
		System.out.println(mod);
		
		System.out.println(twice);
	}
}
